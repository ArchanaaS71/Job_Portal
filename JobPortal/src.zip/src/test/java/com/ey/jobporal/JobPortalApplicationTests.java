package com.ey.jobporal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
