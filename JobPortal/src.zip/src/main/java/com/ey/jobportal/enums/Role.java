package com.ey.jobportal.enums;

public enum Role {
	ADMIN, CONSULTANT, JOBSEEKER
}
