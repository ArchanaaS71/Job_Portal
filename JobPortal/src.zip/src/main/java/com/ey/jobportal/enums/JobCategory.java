package com.ey.jobportal.enums;

public enum JobCategory {
	IT,FINANCE,HEALTHCARE,EDUCATION,MARKETING,CORE_ENGINEERING;

	String getname() {
		// TODO Auto-generated method stub
		return null;
	}

}
