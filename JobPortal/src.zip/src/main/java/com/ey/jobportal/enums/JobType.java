package com.ey.jobportal.enums;

public enum JobType {

	FULL_TIME,PART_TIME,INTERNSHIP
}
