package com.ey.jobportal.enums;

public enum RoleName {
	ROLE_USER, ROLE_EMPLOYER

}
