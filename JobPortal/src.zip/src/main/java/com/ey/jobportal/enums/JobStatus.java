package com.ey.jobportal.enums;

public enum JobStatus {
	OPEN,CLOSED
}
