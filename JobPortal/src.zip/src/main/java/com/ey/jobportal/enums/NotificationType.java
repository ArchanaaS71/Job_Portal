package com.ey.jobportal.enums;

public enum NotificationType {
	JOB_POSTED,JOB_APPLIED,APPLICATION_STATUS,PASSWORD_RESET

}
